package com.josolivar.cidadesapi.paises;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioDePaises extends JpaRepository<Pais,Long> {
}
