package com.josolivar.cidadesapi.estados;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioDeEstados extends JpaRepository<Estado,Long> {
}
